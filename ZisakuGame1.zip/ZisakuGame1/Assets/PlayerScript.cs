﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour {

    public Canvas menuCanvas;                       // メニューキャンバス
    public Button itemButton, soubiButton, magicButton, saveButton, ConfigButton, exitMenuButton;

    public Canvas configCanvas;
    public Toggle moveLeftToggle;

    public Canvas moveCanvas;                       // プレイヤーの移動用キャンバス
    public Button upButton, rightButton, leftButton, downButton, decideButton, openMenuButton;

    Rigidbody2D rigid2D;                            // キャラの移動をいじる
    Animator characterAnimator;                     // キャラの移動アニメーション用
    float x = 170, y = 155;                         // 移動速度
    Vector2 vecUp, vecRight, vecLeft, vecDown, vecDecide;           // ボタンの位置取得用

    string nowTime;
    public Text testText;

	void Start ()
    {
        rigid2D = GetComponent<Rigidbody2D>();
        characterAnimator = GetComponent<Animator>();

        vecUp = upButton.GetComponent<RectTransform>().localPosition;
        vecRight = rightButton.GetComponent<RectTransform>().localPosition;
        vecLeft = leftButton.GetComponent<RectTransform>().localPosition;
        vecDown = downButton.GetComponent<RectTransform>().localPosition;
        vecDecide = decideButton.GetComponent<RectTransform>().localPosition;
    }
	
	// Update is called once per frame
	void Update ()
    {
        nowTime = System.DateTime.Now.ToString();
    }
    //////////////////////////////////////// ＧＵＩ用 ////////////////////////////////////////
    public void OpenMenu()                                  // メニューを表示
    {
        menuCanvas.enabled = true;
        characterAnimator.enabled = false;
    }

    public void ExitMenu()                                  // メニューを非表示
    {
        menuCanvas.enabled = false;
        configCanvas.enabled = false;

        characterAnimator.enabled = true;
    }
    public void PushItem()                                  // アイテムを表示
    {
        PlayerPrefs.SetString("NOW", nowTime);
        PlayerPrefs.Save();
    }

    public void PushSoubi()                                 // 装備を表示
    {
        testText.text = PlayerPrefs.GetString("NOW", "");
    }

    public void PushMagic()                                 // 魔法を表示
    {
        PlayerPrefs.DeleteAll();
    }

    public void PushSave()                                  // セーブを表示
    {

    }

    public void PushConfig()                                // 設定を表示
    {
        configCanvas.enabled = !configCanvas.enabled;
    }

    public void PushUp()
    {
        characterAnimator.SetBool("upFlg", true);
        rigid2D.AddForce(new Vector2(0,y));
    }

    public void PushRight()
    {
        characterAnimator.SetBool("rightFlg", true);
        rigid2D.AddForce(new Vector2(x, 0));
    }

    public void PushLeft()
    {
        characterAnimator.SetBool("leftFlg", true);
        rigid2D.AddForce(new Vector2(-x, 0));
    }

    public void PushDown()
    {
        characterAnimator.SetBool("downFlg", true);
        rigid2D.AddForce(new Vector2(0, -y));
    }

    public void EventPushUp()
    {
        characterAnimator.SetBool("upFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushRight()
    {
        characterAnimator.SetBool("rightFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushLeft()
    {
        characterAnimator.SetBool("leftFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushDown()
    {
        characterAnimator.SetBool("downFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void PushDecide()
    {

    }

    public void MoveLeftToggleOn()
    {
        if (moveLeftToggle.isOn == true) {
            upButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecUp.x, vecUp.y);
            rightButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecLeft.x, vecRight.y);
            leftButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecRight.x, vecLeft.y);
            downButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecDown.x, vecDown.y);
            decideButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecDecide.x, vecDecide.y);
        }
        else if (moveLeftToggle.isOn == false)
        {
            upButton.GetComponent<RectTransform>().localPosition = vecUp;
            rightButton.GetComponent<RectTransform>().localPosition = vecRight;
            leftButton.GetComponent<RectTransform>().localPosition = vecLeft;
            downButton.GetComponent<RectTransform>().localPosition = vecDown;
            decideButton.GetComponent<RectTransform>().localPosition = vecDecide;
        }
    }

    //////////////////////////////////////// メソッド ////////////////////////////////////////
    void DebugM()                                                           // DebugMethod
    {
        Debug.Log("みょーん(・ω・)y");
    }
    
}