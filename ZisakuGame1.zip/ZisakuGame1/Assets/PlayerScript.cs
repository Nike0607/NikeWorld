﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour {

    public Canvas menuCanvas;                                       // メニューキャンバス
    public Button itemButton, soubiButton, magicButton, saveButton, ConfigButton, exitMenuButton;

    public Canvas configCanvas;                                     // 設定キャンバス
    public Toggle moveLeftToggle;

    public Canvas moveCanvas;                                       // プレイヤーの移動用キャンバス
    public Button upButton, rightButton, leftButton, downButton, decideButton, openMenuButton;

    public Canvas battleCanvas;                                     // 戦闘キャンバス

    Rigidbody2D rigid2D;                                            // キャラの移動をいじる
    Animator characterAnimator;                                     // キャラの移動アニメーション用
    float x = 170, y = 155;                                         // 移動速度
    Vector2 vecUp, vecRight, vecLeft, vecDown, vecDecide;           // ボタンの位置取得用
    List<int> encount = new List<int>();                            // 敵エンカウント用
    int start = 0, end = 15, encCount, rndEnc, rtnEnc;              // エンカウントに使う変数
    float encTime;                                                  // エンカウント用の時間
    Vector2 beforePos, nowPos;                                      // ぶつかりチェック


    string nowTime;
    public Text testText;

	void Start ()
    {
        rigid2D = GetComponent<Rigidbody2D>();
        characterAnimator = GetComponent<Animator>();

        vecUp = upButton.GetComponent<RectTransform>().localPosition;           // 移動ボタンの初期位置を保存
        vecRight = rightButton.GetComponent<RectTransform>().localPosition;
        vecLeft = leftButton.GetComponent<RectTransform>().localPosition;
        vecDown = downButton.GetComponent<RectTransform>().localPosition;
        vecDecide = decideButton.GetComponent<RectTransform>().localPosition;

        for (int i = start; i < end; i++){ encount.Add(i); }            // 0 ～ 19をencountリストに追加
        encCount = encount.Count;
    }
	
	void Update ()
    {
        nowTime = System.DateTime.Now.ToString();

        if (rigid2D.velocity.x != 0 || rigid2D.velocity.y != 0)                 // キャラが移動している時
        {
            nowPos = rigid2D.transform.position;
            if(beforePos == nowPos){ return; }                                  // 移動できていない時は抜ける
            
            encTime += Time.deltaTime;
            testText.text = encTime.ToString();
            if(encTime >= 0.7f)                                                 // 移動して0.7秒経ったら
            {
                encTime = 0;
                rtnEnc = EncountCheck();
                Debug.Log(rtnEnc);
                if (rtnEnc == 0)
                {
                    battleCanvas.enabled = true;
                    encCount = encount.Count;
                }
            }
        }
    }

    //////////////////////////////////////// ＧＵＩ用 ////////////////////////////////////////
    public void OpenMenu()                                  // メニューを表示
    {
        menuCanvas.enabled = true;
        characterAnimator.enabled = false;
        battleCanvas.enabled = false;                       // バトルキャンバスを非表示(後で変更)
    }

    public void ExitMenu()                                  // メニューを非表示
    {
        menuCanvas.enabled = false;
        configCanvas.enabled = false;

        characterAnimator.enabled = true;
    }
    public void PushItem()                                  // アイテムを表示
    {
        PlayerPrefs.SetString("NOW", nowTime);
        PlayerPrefs.Save();
    }

    public void PushSoubi()                                 // 装備を表示
    {
        testText.text = PlayerPrefs.GetString("NOW", "");
    }

    public void PushMagic()                                 // 魔法を表示
    {
        PlayerPrefs.DeleteAll();
    }

    public void PushSave()                                  // セーブを表示
    {

    }

    public void PushConfig()                                // 設定を表示
    {
        configCanvas.enabled = !configCanvas.enabled;
    }

    public void PushUp()
    {
        characterAnimator.SetBool("upFlg", true);
        rigid2D.AddForce(new Vector2(0,y));
        beforePos = rigid2D.transform.position;
    }

    public void PushRight()
    {
        characterAnimator.SetBool("rightFlg", true);
        rigid2D.AddForce(new Vector2(x, 0));
        beforePos = rigid2D.transform.position;
    }

    public void PushLeft()
    {
        characterAnimator.SetBool("leftFlg", true);
        rigid2D.AddForce(new Vector2(-x, 0));
        beforePos = rigid2D.transform.position;
    }

    public void PushDown()
    {
        characterAnimator.SetBool("downFlg", true);
        rigid2D.AddForce(new Vector2(0, -y));
        beforePos = rigid2D.transform.position;
    }

    public void EventPushUp()
    {
        characterAnimator.SetBool("upFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushRight()
    {
        characterAnimator.SetBool("rightFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushLeft()
    {
        characterAnimator.SetBool("leftFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void EventPushDown()
    {
        characterAnimator.SetBool("downFlg", false);
        rigid2D.velocity = new Vector2(0f, 0f);
    }

    public void PushDecide()
    {

    }

    public void MoveLeftToggleOn()                      // 移動ボタンの位置
    {
        if (moveLeftToggle.isOn == true) {
            upButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecUp.x, vecUp.y);
            rightButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecLeft.x, vecRight.y);
            leftButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecRight.x, vecLeft.y);
            downButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecDown.x, vecDown.y);
            decideButton.GetComponent<RectTransform>().localPosition = new Vector2(-vecDecide.x, vecDecide.y);
        }
        else if (moveLeftToggle.isOn == false)
        {
            upButton.GetComponent<RectTransform>().localPosition = vecUp;
            rightButton.GetComponent<RectTransform>().localPosition = vecRight;
            leftButton.GetComponent<RectTransform>().localPosition = vecLeft;
            downButton.GetComponent<RectTransform>().localPosition = vecDown;
            decideButton.GetComponent<RectTransform>().localPosition = vecDecide;
        }
    }

    //////////////////////////////////////// メソッド ////////////////////////////////////////
    void DM()                                       // DebugMethod
    {
        Debug.Log("みょーん(・ω・)y");
    }
    
    int EncountCheck()                                  // 0 ～ 19ランダムに値を抽出し返す
    {
        rndEnc = Random.Range(0,encCount);              // Random.Range(0以上,要素数より小さい)
        encCount--;                                     // 要素数を1減らして、範囲を縮める
        return rndEnc;
    }
}