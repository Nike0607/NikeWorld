﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;                      // LoadSceneを使うため

public class MainScript : MonoBehaviour {

    public Canvas TitleCanvas;
    public Button StartButton, RestartButton, ConfigButton;
    
	void Start ()
    {
		
	}
	
	void Update ()
    {
		
	}

    //////////////////////////////////////////// ＧＵＩ用 ////////////////////////////////////////////
    
    public void PushStart()
    {
        SceneManager.LoadScene("MaouScene");
    }

    public void PushRestart()
    {

    }

    public void PushConfig()
    {

    }
    //////////////////////////////////////////// メソッド ////////////////////////////////////////////
}
