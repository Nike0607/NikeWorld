####　ダウンロードありがとうございます！　####

「操作方法」
・X移動　　：　A、D、←、→
・Y移動　　：　W、S、↑、↓
・弾の発射 ：　Space

「解像度」
・1280 x 720

※UI表示がずれるため、起動時に解像度を合わせてください。

#### Thank you for downloading! ####

"How to operation"
・X movement　　: A, D, ←, →
・Y movement　　: W, S, ↑, ↓
・Bullet launch : Space

"Resolution"
・ 1280 x 720

* Since the UI display is shifted, please adjust the resolution at startup.